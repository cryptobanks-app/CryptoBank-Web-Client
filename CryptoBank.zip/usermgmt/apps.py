from django.apps import AppConfig


class UsermgmtConfig(AppConfig):
    name = 'usermgmt'
