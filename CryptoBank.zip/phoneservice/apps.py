from django.apps import AppConfig


class PhoneserviceConfig(AppConfig):
    name = 'phoneservice'
